﻿namespace ClassLibrary1
{
    public class ExampleClass
    {
        public void DoSomething()
        {
            throw new Exception("This is an exception from the class library.");
        }
    }

}
