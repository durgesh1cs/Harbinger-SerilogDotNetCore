﻿using ClassLibrary1;
using Microsoft.AspNetCore.Mvc;

namespace Serilog_Logging.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ExampleController : ControllerBase
    {
        private readonly ExampleClass _exampleClass;

        public ExampleController()
        {
            _exampleClass = new ExampleClass();
        }

        [HttpGet]
        public IActionResult Get()
        {
            _exampleClass.DoSomething();
            return Ok("Success");
        }
    }

}
